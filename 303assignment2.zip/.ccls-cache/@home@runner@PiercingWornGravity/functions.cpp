#include "functions.h"

Linked::Linked() : headPtr(nullptr), tailPtr(nullptr), num_items(0) {}

Linked::~Linked() {
    clear();
}

void Linked::addNode(dataType d) {
    push_back(d);
}

void Linked::delNode(const dataType& name) {
    size_t index = find(name);
    if (index != num_items) {
        remove(index);
    }
}

void Linked::printList() {
    Node* current = headPtr;
    while (current != nullptr) {
        cout << "Name: " << current->data.name << ", Age: " << current->data.age << endl;
        current = current->nextPtr;
    }
}

void Linked::push_front(dataType d) {
    Node* newNode = new Node;
    newNode->data = d;
    newNode->nextPtr = headPtr;
    headPtr = newNode;
    if (tailPtr == nullptr) {
        tailPtr = newNode;
    }
    num_items++;
}

void Linked::push_back(dataType d) {
    Node* newNode = new Node;
    newNode->data = d;
    newNode->nextPtr = nullptr;
    if (tailPtr != nullptr) {
        tailPtr->nextPtr = newNode;
    }
    tailPtr = newNode;
    if (headPtr == nullptr) {
        headPtr = newNode;
    }
    num_items++;
}

void Linked::pop_front() {
    if (headPtr != nullptr) {
        Node* temp = headPtr;
        headPtr = headPtr->nextPtr;
        delete temp;
        if (headPtr == nullptr) {
            tailPtr = nullptr;
        }
        num_items--;
    }
}

void Linked::pop_back() {
    if (headPtr != nullptr) {
        if (headPtr == tailPtr) {
            delete headPtr;
            headPtr = tailPtr = nullptr;
        } else {
            Node* current = headPtr;
            while (current->nextPtr != tailPtr) {
                current = current->nextPtr;
            }
            delete tailPtr;
            tailPtr = current;
            tailPtr->nextPtr = nullptr;
        }
        num_items--;
    }
}

dataType Linked::front() {
    if (headPtr != nullptr) {
        return headPtr->data;
    }
    throw runtime_error("List is empty");
}

dataType Linked::back() {
    if (tailPtr != nullptr) {
        return tailPtr->data;
    }
    throw runtime_error("List is empty");
}

bool Linked::empty() {
    return num_items == 0;
}

void Linked::insert(size_t index, const dataType& d) {
    if (index > num_items) {
        index = num_items;
    }
    if (index == 0) {
        push_front(d);
    } else if (index == num_items) {
        push_back(d);
    } else {
        Node* newNode = new Node;
        newNode->data = d;
        Node* current = headPtr;
        for (size_t i = 0; i < index - 1; ++i) {
            current = current->nextPtr;
        }
        newNode->nextPtr = current->nextPtr;
        current->nextPtr = newNode;
        num_items++;
    }
}

bool Linked::remove(size_t index) {
    if (index >= num_items) {
        return false;
    }
    if (index == 0) {
        pop_front();
    } else {
        Node* current = headPtr;
        for (size_t i = 0; i < index - 1; ++i) {
            current = current->nextPtr;
        }
        Node* temp = current->nextPtr;
        current->nextPtr = temp->nextPtr;
        delete temp;
        if (index == num_items - 1) {
            tailPtr = current;
        }
        num_items--;
    }
    return true;
}

size_t Linked::find(const dataType& d) {
    Node* current = headPtr;
    size_t index = 0;
    while (current != nullptr) {
        if (current->data.name == d.name) {
            return index;
        }
        current = current->nextPtr;
        index++;
    }
    return num_items;
}

void Linked::clear() {
    while (headPtr != nullptr) {
        Node* temp = headPtr;
        headPtr = headPtr->nextPtr;
        delete temp;
    }
    tailPtr = nullptr;
    num_items = 0;
}

void Stack::push(int value) {
    data.push_back(value);
}

void Stack::pop() {
    if (!empty()) {
        data.pop_back();
    }
}

bool Stack::empty() const {
    return data.empty();
}

int Stack::top() const {
    if (!empty()) {
        return data.back();
    }
    throw runtime_error("Stack is empty");
}

double Stack::average() const {
    if (empty()) {
        return 0.0;
    }
    double sum = accumulate(data.begin(), data.end(), 0.0);
    return sum / data.size();
}