#include "functions.h"

int main() {
    Stack stack;
    char choice;

    do {
        cout << "Choose an operation:" << endl;
        cout << "1. Check if stack is empty" << endl;
        cout << "2. Insert an integer value onto the stack" << endl;
        cout << "3. Remove an element from the stack" << endl;
        cout << "4. Find the top of the stack" << endl;
        cout << "5. Find average value of the stack elements" << endl;
        cout << "6. Exit" << endl;
        cout << "Enter your choice: " << endl;
        cin >> choice;

        switch (choice) {
            case '1': {
                cout << "Is stack empty? " << (stack.empty() ? "Yes" : "No") << endl;
                break;
            }
            case '2': {
                int value;
                cout << "Enter an integer value to push onto the stack: ";
                cin >> value;
                stack.push(value);
                cout << "Value pushed onto the stack." << endl;
                break;
            }
            case '3': {
                if (!stack.empty()) {
                    stack.pop();
                    cout << "Element removed from the stack." << endl;
                } else {
                    cout << "Stack is empty. No elements to remove." << endl;
                }
                break;
            }
            case '4': {
                if (!stack.empty()) {
                    cout << "Top of the stack: " << stack.top() << endl;
                } else {
                    cout << "Stack is empty. No top element." << endl;
                }
                break;
            }
            case '5': {
                if (!stack.empty()) {
                    cout << "Average value of the stack elements: " << stack.average() << endl;
                } else {
                    cout << "Stack is empty. No elements to find average." << endl;
                }
                break;
            }
            case '6': {
                cout << "Exiting program." << endl;
                break;
            }
            default:
                cout << "Invalid choice. Please enter a valid option." << endl;
        }
    } while (choice != '6');

    return 0;
}