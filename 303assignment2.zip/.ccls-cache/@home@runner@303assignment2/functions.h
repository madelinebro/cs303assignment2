#pragma once
#include <string>
#include <iostream>
#include <iostream>
#include <vector>
#include <numeric>

using namespace std;

struct dataType {
    char type;
    string name;
    int age;
};

struct Node {
    dataType data;
    Node* nextPtr;
};

class Linked {
protected:
    Node* headPtr;
    Node* tailPtr;
    size_t num_items; 
public:
    Linked();
    ~Linked();
    void addNode(dataType d);
    void delNode(const dataType& name);
    void printList();
    void push_front(dataType d); 
    void push_back(dataType d); 
    void pop_front(); 
    void pop_back(); 
    void clear();
    dataType front(); 
    dataType back(); 
    bool empty(); 
    void insert(size_t index, const dataType& d); 
    bool remove(size_t index); 
    size_t find(const dataType& d); 
};

class Stack {
private:
    vector<int> data;

public:
    void push(int value);
    void pop();
    bool empty() const;
    int top() const;
    double average() const;
};
